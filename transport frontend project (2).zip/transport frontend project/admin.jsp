<%-- 
    Document   : admin
    Created on : 14 May, 2025, 6:43:13 PM
    Author     : KIIT
--%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <%@page import="java.sql.DriverManager"%>
        <%@page import="java.sql.ResultSet"%>
        <%@page import="java.sql.Statement"%>
        <%@page import="java.sql.Connection"%>
        <%@page import="java.sql.*,java.util.*"%>
        <%
            String myname = request.getParameter("name");
            String mypassword = request.getParameter("password");
            try {
                Class.forName("oracle.jdbc.driver.OracleDriver");
                Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "loyndas1234");
                //Statement st=con.createStatement();
                PreparedStatement ps = con.prepareStatement("SELECT * FROM ADMINLOGIN WHERE Username = ? AND password = ?");
                ps.setString(1, myname);
                ps.setString(2, mypassword);
                ResultSet rs=ps.executeQuery();
                if (rs.next()) {
                    response.sendRedirect("admindashboard.html");
                } else {
                    out.println("Invalid username/password");
                }
                rs.close();
            ps.close();
            con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        %>
    </body>
</html>
