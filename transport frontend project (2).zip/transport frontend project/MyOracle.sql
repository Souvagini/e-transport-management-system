CREATE TABLE UserRegistration (
    Username VARCHAR2(30),
    Name VARCHAR2(30),
    EmailAddress VARCHAR2(50),
    phoneno VARCHAR2(15),
    password VARCHAR2(20),
    dob DATE,
    country VARCHAR2(30),
    states VARCHAR2(30),
    City VARCHAR2(30),
    gender VARCHAR2(10)
);
