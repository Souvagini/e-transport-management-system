<%-- 
    Document   : howitworks
    Created on : 14 May, 2025, 1:51:58 PM
    Author     : KIIT
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%
    int distance = Integer.parseInt(request.getParameter("distance"));
    String vehicle = request.getParameter("vehicle");
    int pricePerKm = (vehicle.equals("car")) ? 100 : 50;
    int totalPrice = distance * pricePerKm;
%>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Price Calculation</title>
    <style>
        body {
            background-color: #d7c9ff;
            font-family: Arial, sans-serif;
            text-align: center;
            margin-top: 50px;
        }

        .container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px #000;
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Calculated Price</h1>
        <p>Distance: <%= distance %> km</p>
        <p>Total Price: Rs <%= totalPrice %></p>
    </div>
</body>
</html>