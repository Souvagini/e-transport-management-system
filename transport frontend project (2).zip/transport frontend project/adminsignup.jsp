<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Registration Success</title>
    </head>
    <body>
        <h2>Registration Successful!</h2>
        <p>Thank you for registering. You can now <a href="adminlogin.html">login</a> with your credentials.</p>
    </body>
</html>
